import {chromium,expect} from '@playwright/test';
async function main(){const b=await chromium.launch({executablePath:process.env.KLINI_CHROMIUM_EXECUTABLE_PATH});const p=await b.newPage({viewport:{width:390,height:844}});try{
await p.goto('http://127.0.0.1:8096');await expect(p.getByTestId('quick-register')).toHaveAccessibleName('Registrar información de salud');
await p.screenshot({path:'test-results/home-register.png'});await p.getByTestId('quick-register').click();await p.waitForURL('**/register');
await expect(p.getByText('Agregar registro',{exact:true})).toBeVisible();
await p.getByTestId('record-title').fill('Registro de prueba');await p.getByTestId('save-record').click();
await expect(p.getByText('Registro de prueba',{exact:true})).toBeVisible();await p.reload();await expect(p.getByTestId('record-title')).toBeVisible();
await p.getByRole('button',{name:'Volver',exact:true}).click();await expect(p.getByText('Registro de prueba',{exact:true})).toBeVisible();
console.log('PASS botón Registro abre formulario de salud y conserva el registro guardado.');
}finally{await b.close();}}main().catch(e=>{console.error(e);process.exitCode=1;});
