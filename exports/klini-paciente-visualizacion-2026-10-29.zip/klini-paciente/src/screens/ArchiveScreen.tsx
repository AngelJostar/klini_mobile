import React, { useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import {
  Button,
  Card,
  Chip,
  colors,
  confirmAction,
  Empty,
  notify,
  Row,
  SectionTitle,
  styles,
  TextField,
} from '../components/ui';
import { dateLabel, todayISO } from '../domain/dates';
import type { ClinicalRecord, Medication } from '../domain/types';
import { openAttachment, pickAttachment } from '../services/files';
import { useAppStore } from '../state/store';
import Sheet from '../components/ArchivePopup';

type RecordDraft = Omit<ClinicalRecord, 'id'>;
type MedicationDraft = Omit<Medication, 'id'>;
type Page = 'list' | 'record' | 'recordForm' | 'medicationForm';
const recordTypes: ClinicalRecord['type'][] = ['Consulta', 'Estudio', 'Receta', 'Vacuna', 'Nota'];
const recordIcons: Record<ClinicalRecord['type'], string> = {
  Consulta: 'doctor',
  Estudio: 'activity',
  Receta: 'document',
  Vacuna: 'shield',
  Nota: 'file',
};
const newRecord = (): RecordDraft => ({
  type: 'Consulta',
  title: '',
  date: todayISO(),
  doctorName: '',
  description: '',
});
const newMedication = (): MedicationDraft => ({
  name: '',
  dose: '',
  frequency: '',
  startDate: todayISO(),
  endDate: '',
  active: true,
});
function isDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const d = new Date(year, month - 1, day, 12);
  return (
    year >= 1900 && d.getFullYear() === year && d.getMonth() === month - 1 && d.getDate() === day
  );
}
function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Intenta de nuevo.';
}

export default function ArchiveScreen({
  onClose,
  initialType,
  initialCreate = false,
  initialTab = 'records',
}: {
  onClose: () => void;
  initialType?: ClinicalRecord['type'];
  initialCreate?: boolean;
  initialTab?: 'records' | 'medications';
}) {
  const {
    state,
    storageError,
    addRecord,
    updateRecord,
    deleteRecord,
    addMedication,
    updateMedication,
    deleteMedication,
  } = useAppStore();
  const [tab, setTab] = useState<'records' | 'medications'>(initialTab);
  const [page, setPage] = useState<Page>(initialCreate ? 'recordForm' : 'list');
  const [query, setQuery] = useState('');
  const [type, setType] = useState<ClinicalRecord['type'] | 'Todos'>(initialType ?? 'Todos');
  const [medicationFilter, setMedicationFilter] = useState<'Todos' | 'Vigentes' | 'Anteriores'>(
    'Vigentes',
  );
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [recordDraft, setRecordDraft] = useState<RecordDraft>(newRecord);
  const [medicationDraft, setMedicationDraft] = useState<MedicationDraft>(newMedication);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const selectedRecord = state.records.find((record) => record.id === selectedId);
  const records = useMemo(() => {
    const text = query.trim().toLocaleLowerCase('es');
    return state.records
      .filter(
        (record) =>
          (type === 'Todos' || record.type === type) &&
          (!text ||
            `${record.title} ${record.doctorName} ${record.description} ${record.date}`
              .toLocaleLowerCase('es')
              .includes(text)),
      )
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [state.records, query, type]);
  const medications = useMemo(
    () =>
      state.medications
        .filter(
          (item) =>
            medicationFilter === 'Todos' ||
            (medicationFilter === 'Vigentes' ? item.active : !item.active),
        )
        .sort((a, b) => b.startDate.localeCompare(a.startDate)),
    [state.medications, medicationFilter],
  );
  const back = () => {
    setError('');
    setPage('list');
  };
  function startRecord(record?: ClinicalRecord) {
    setEditingId(record?.id ?? null);
    setRecordDraft(
      record
        ? {
            type: record.type,
            title: record.title,
            date: record.date,
            doctorName: record.doctorName,
            description: record.description,
            attachment: record.attachment,
          }
        : newRecord(),
    );
    setError('');
    setPage('recordForm');
  }
  function startMedication(item?: Medication) {
    setEditingId(item?.id ?? null);
    setMedicationDraft(
      item
        ? {
            name: item.name,
            dose: item.dose,
            frequency: item.frequency,
            startDate: item.startDate,
            endDate: item.endDate || '',
            active: item.active,
          }
        : newMedication(),
    );
    setError('');
    setPage('medicationForm');
  }
  async function attach() {
    setBusy(true);
    setError('');
    try {
      const attachment = await pickAttachment();
      if (attachment) setRecordDraft((draft) => ({ ...draft, attachment }));
    } catch (e) {
      setError(`No se pudo adjuntar el archivo. ${errorMessage(e)}`);
    } finally {
      setBusy(false);
    }
  }
  async function openFile(record: Pick<ClinicalRecord, 'attachment'>) {
    if (!record.attachment) return;
    try {
      await openAttachment(record.attachment);
    } catch (e) {
      notify('No se pudo abrir el archivo', errorMessage(e));
    }
  }
  function saveRecord() {
    if (!recordDraft.title.trim()) return setError('Escribe un título para el registro.');
    if (!isDate(recordDraft.date) || recordDraft.date > todayISO())
      return setError('Usa una fecha real con formato AAAA-MM-DD, igual o anterior a hoy.');
    const data = {
      ...recordDraft,
      title: recordDraft.title.trim(),
      doctorName: recordDraft.doctorName.trim(),
      description: recordDraft.description.trim(),
    };
    try {
      if (editingId) updateRecord(editingId, data);
      else addRecord(data);
      setError('');
      setPage('list');
      setTab('records');
    } catch (e) {
      setError(`No se pudo guardar el registro. ${errorMessage(e)}`);
    }
  }
  function removeRecord(record: ClinicalRecord) {
    confirmAction(
      'Eliminar registro',
      `Se eliminará “${record.title}” de este dispositivo. Esta acción no se puede deshacer.`,
      () => {
        try {
          deleteRecord(record.id);
          setSelectedId(null);
          setPage('list');
        } catch (e) {
          notify('No se pudo eliminar', errorMessage(e));
        }
      },
    );
  }
  function saveMedication() {
    if (!medicationDraft.name.trim()) return setError('Escribe el nombre del medicamento.');
    if (!medicationDraft.dose.trim())
      return setError('Escribe la dosis tal como aparece en tu receta.');
    if (!medicationDraft.frequency.trim())
      return setError('Escribe la frecuencia indicada en tu receta.');
    if (!isDate(medicationDraft.startDate))
      return setError('Usa una fecha de inicio real con formato AAAA-MM-DD.');
    if (
      medicationDraft.endDate &&
      (!isDate(medicationDraft.endDate) || medicationDraft.endDate < medicationDraft.startDate)
    )
      return setError('La fecha de fin debe ser real e igual o posterior al inicio.');
    const data = {
      ...medicationDraft,
      name: medicationDraft.name.trim(),
      dose: medicationDraft.dose.trim(),
      frequency: medicationDraft.frequency.trim(),
      endDate: medicationDraft.endDate || undefined,
    };
    try {
      if (editingId) updateMedication(editingId, data);
      else addMedication(data);
      setError('');
      setPage('list');
      setTab('medications');
      setMedicationFilter(data.active ? 'Vigentes' : 'Anteriores');
    } catch (e) {
      setError(`No se pudo guardar el medicamento. ${errorMessage(e)}`);
    }
  }
  function removeMedication(item: Medication) {
    confirmAction(
      'Eliminar medicamento',
      `Se eliminará el registro de “${item.name}”. Esto no modifica ninguna receta médica.`,
      () => {
        try {
          deleteMedication(item.id);
        } catch (e) {
          notify('No se pudo eliminar', errorMessage(e));
        }
      },
    );
  }
  const errorView = error ? (
    <Text accessibilityRole="alert" style={styles.error}>
      {error}
    </Text>
  ) : null;
  if (page === 'recordForm')
    return (
      <Sheet
        title={editingId ? 'Editar registro' : 'Agregar registro'}
        onClose={onClose}
        onBack={back}
        footer={
          <Button
            title="Guardar registro"
            onPress={saveRecord}
            disabled={busy}
            testID="save-record"
            icon="check"
          />
        }
      >
        <Text style={styles.body}>
          Registra información de tu historial y conserva su archivo original.
        </Text>
        <SectionTitle>Tipo de registro</SectionTitle>
        <View style={styles.wrap}>
          {recordTypes.map((item) => (
            <Chip
              key={item}
              label={item}
              selected={recordDraft.type === item}
              onPress={() => setRecordDraft((draft) => ({ ...draft, type: item }))}
            />
          ))}
        </View>
        <TextField
          label="Título *"
          value={recordDraft.title}
          onChangeText={(title) => setRecordDraft((draft) => ({ ...draft, title }))}
          placeholder="Ej. Consulta de medicina general"
          maxLength={120}
          testID="record-title"
        />
        <TextField
          label="Fecha * (AAAA-MM-DD)"
          value={recordDraft.date}
          onChangeText={(date) => setRecordDraft((draft) => ({ ...draft, date }))}
          placeholder="2026-10-20"
          maxLength={10}
          keyboardType="numbers-and-punctuation"
          testID="record-date"
        />
        <TextField
          label="Profesional o laboratorio"
          value={recordDraft.doctorName}
          onChangeText={(doctorName) => setRecordDraft((draft) => ({ ...draft, doctorName }))}
          placeholder="Opcional"
          maxLength={120}
        />
        <TextField
          label="Detalles"
          value={recordDraft.description}
          onChangeText={(description) => setRecordDraft((draft) => ({ ...draft, description }))}
          placeholder="Notas del registro, fuente o información útil"
          multiline
          maxLength={6000}
        />
        <SectionTitle>Archivo adjunto</SectionTitle>
        <Text style={[styles.small, { marginBottom: 8 }]}>
          PDF, imagen o texto · Hasta 2 MB. También puedes guardar sin un archivo.
        </Text>
        {recordDraft.attachment ? (
          <Card>
            <Row
              title={recordDraft.attachment.name}
              subtitle="Abrir o descargar archivo"
              icon="attachment"
              onPress={() => openFile(recordDraft)}
            />
            <Button
              title="Quitar archivo"
              secondary
              onPress={() => setRecordDraft((draft) => ({ ...draft, attachment: undefined }))}
            />
          </Card>
        ) : null}
        <Button
          title={
            busy
              ? 'Abriendo selector…'
              : recordDraft.attachment
                ? 'Cambiar archivo'
                : 'Adjuntar archivo'
          }
          onPress={attach}
          secondary
          disabled={busy}
          icon="attachment"
          testID="attach-record-file"
        />
        {errorView}
      </Sheet>
    );

  if (page === 'medicationForm')
    return (
      <Sheet
        title={editingId ? 'Editar medicamento' : 'Agregar medicamento'}
        onClose={onClose}
        onBack={back}
        footer={
          <Button
            title="Guardar medicamento"
            onPress={saveMedication}
            testID="save-medication"
            icon="check"
          />
        }
      >
        <Text style={styles.body}>
          Copia los datos de tu receta. El registro no indica cambios de tratamiento.
        </Text>
        <View style={{ height: 14 }} />
        <TextField
          label="Medicamento *"
          value={medicationDraft.name}
          onChangeText={(name) => setMedicationDraft((draft) => ({ ...draft, name }))}
          maxLength={120}
          testID="medication-name"
        />
        <TextField
          label="Dosis registrada *"
          value={medicationDraft.dose}
          onChangeText={(dose) => setMedicationDraft((draft) => ({ ...draft, dose }))}
          placeholder="Tal como aparece en la receta"
          maxLength={120}
          testID="medication-dose"
        />
        <TextField
          label="Frecuencia registrada *"
          value={medicationDraft.frequency}
          onChangeText={(frequency) => setMedicationDraft((draft) => ({ ...draft, frequency }))}
          placeholder="Tal como aparece en la receta"
          maxLength={180}
          testID="medication-frequency"
        />
        <TextField
          label="Inicio * (AAAA-MM-DD)"
          value={medicationDraft.startDate}
          onChangeText={(startDate) => setMedicationDraft((draft) => ({ ...draft, startDate }))}
          maxLength={10}
          keyboardType="numbers-and-punctuation"
        />
        <TextField
          label="Fin (opcional, AAAA-MM-DD)"
          value={medicationDraft.endDate || ''}
          onChangeText={(endDate) => setMedicationDraft((draft) => ({ ...draft, endDate }))}
          maxLength={10}
          keyboardType="numbers-and-punctuation"
        />
        <Card>
          <View style={local.switchRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Tratamiento vigente</Text>
              <Text style={styles.small}>Estado del registro en tu archivo.</Text>
            </View>
            <Switch
              accessibilityLabel="Tratamiento vigente"
              value={medicationDraft.active}
              onValueChange={(active) => setMedicationDraft((draft) => ({ ...draft, active }))}
              trackColor={{ true: colors.teal, false: colors.line }}
            />
          </View>
        </Card>
        {errorView}
      </Sheet>
    );

  if (page === 'record' && selectedRecord)
    return (
      <Sheet
        title={selectedRecord.type}
        onClose={onClose}
        onBack={back}
        footer={
          <Button
            title="Editar registro"
            onPress={() => startRecord(selectedRecord)}
            icon="edit"
            testID="edit-record"
          />
        }
      >
        <Text style={styles.title}>{selectedRecord.title}</Text>
        <Text style={[styles.body, { marginTop: 7 }]}>
          {dateLabel(selectedRecord.date)} · {selectedRecord.date}
        </Text>
        <SectionTitle>Profesional o laboratorio</SectionTitle>
        <Text style={styles.rowTitle}>
          {selectedRecord.doctorName || 'Sin información registrada'}
        </Text>
        <SectionTitle>Detalles del registro</SectionTitle>
        <Card>
          <Text selectable style={styles.body}>
            {selectedRecord.description || 'No hay detalles adicionales.'}
          </Text>
        </Card>
        <SectionTitle>Archivo original</SectionTitle>
        {selectedRecord.attachment ? (
          <Card>
            <Row
              title={selectedRecord.attachment.name}
              subtitle="Abrir o descargar archivo adjunto"
              icon="attachment"
              onPress={() => openFile(selectedRecord)}
            />
          </Card>
        ) : (
          <Empty
            title="Sin archivo adjunto"
            description="Puedes adjuntarlo al editar este registro."
          />
        )}
        <Button
          title="Eliminar registro"
          danger
          onPress={() => removeRecord(selectedRecord)}
          icon="trash"
        />
      </Sheet>
    );

  return (
    <Sheet
      title={tab === 'medications' ? 'Medicamentos' : type === 'Receta' ? 'Recetas' : type === 'Consulta' ? 'Historial' : 'Registros'}
      onClose={onClose}
      footer={
        <Button
          title={tab === 'records' ? 'Agregar registro' : 'Agregar medicamento'}
          onPress={() => (tab === 'records' ? startRecord() : startMedication())}
          icon="plus"
          testID="add-archive-item"
        />
      }
    >
      <Text style={styles.title}>Tu historia, organizada.</Text>
      <Text style={[styles.body, { marginTop: 6, marginBottom: 14 }]}>
        {state.profile.name} · Información local de demostración
      </Text>
      {storageError && (
        <Text accessibilityRole="alert" style={styles.error}>
          {storageError}
        </Text>
      )}
      <View style={styles.wrap}>
        <Chip label="Historial" selected={tab === 'records'} onPress={() => setTab('records')} />
        <Chip
          label="Medicamentos"
          selected={tab === 'medications'}
          onPress={() => setTab('medications')}
        />
      </View>
      {tab === 'records' ? (
        <>
          <TextField
            placeholder="Buscar por título, profesional o detalle"
            value={query}
            onChangeText={setQuery}
            testID="archive-search"
          />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
            <Chip label="Todos" selected={type === 'Todos'} onPress={() => setType('Todos')} />
            {recordTypes.map((item) => (
              <Chip
                key={item}
                label={item}
                selected={type === item}
                onPress={() => setType(item)}
              />
            ))}
          </ScrollView>
          <Text style={styles.small}>
            {records.length} {records.length === 1 ? 'registro' : 'registros'} · Más recientes
            primero
          </Text>
          {records.length === 0 ? (
            <Empty
              title={state.records.length ? 'Sin coincidencias' : 'Tu historial empieza aquí'}
              description={
                state.records.length
                  ? 'Prueba con otra búsqueda o tipo de registro.'
                  : 'Agrega una consulta, estudio, receta, vacuna o nota.'
              }
              action={state.records.length ? 'Limpiar búsqueda' : 'Agregar registro'}
              onAction={() =>
                state.records.length ? (setQuery(''), setType('Todos')) : startRecord()
              }
            />
          ) : (
            records.map((record) => (
              <Card key={record.id} style={{ marginTop: 10 }}>
                <Text style={styles.badge}>
                  {record.type} · {record.date}
                </Text>
                <Row
                  title={record.title}
                  subtitle={`${record.doctorName || 'Añadido por ti'}${record.attachment ? ' · Archivo adjunto' : ''}`}
                  icon={recordIcons[record.type]}
                  onPress={() => {
                    setSelectedId(record.id);
                    setPage('record');
                  }}
                />
              </Card>
            ))
          )}
        </>
      ) : (
        <>
          <View style={[styles.wrap, { marginTop: 6 }]}>
            {(['Vigentes', 'Anteriores', 'Todos'] as const).map((item) => (
              <Chip
                key={item}
                label={item}
                selected={medicationFilter === item}
                onPress={() => setMedicationFilter(item)}
              />
            ))}
          </View>
          <Text style={[styles.small, { marginBottom: 10 }]}>
            Información copiada de tus recetas; no modifica un tratamiento.
          </Text>
          {medications.length === 0 ? (
            <Empty
              title="Sin medicamentos en esta vista"
              description="Agrega un registro o cambia el filtro."
              action="Agregar medicamento"
              onAction={() => startMedication()}
            />
          ) : (
            medications.map((item) => (
              <Card key={item.id}>
                <Row
                  title={item.name}
                  subtitle={item.active ? 'Vigente' : 'Anterior'}
                  icon="pill"
                  onPress={() => startMedication(item)}
                />
                <Text style={styles.body}>Dosis: {item.dose}</Text>
                <Text style={styles.body}>Frecuencia: {item.frequency}</Text>
                <Text style={[styles.small, { marginTop: 5 }]}>
                  Desde {item.startDate}
                  {item.endDate ? ` · Hasta ${item.endDate}` : ''}
                </Text>
                <View style={[local.switchRow, { marginTop: 12 }]}>
                  <Text style={[styles.rowTitle, { flex: 1 }]}>Marcar como vigente</Text>
                  <Switch
                    accessibilityLabel={`Tratamiento vigente: ${item.name}`}
                    value={item.active}
                    onValueChange={(active) => {
                      try {
                        updateMedication(item.id, { active });
                      } catch (e) {
                        notify('No se pudo actualizar', errorMessage(e));
                      }
                    }}
                    trackColor={{ true: colors.teal, false: colors.line }}
                  />
                </View>
                <View style={local.actions}>
                  <View style={{ flex: 1 }}>
                    <Button
                      title="Editar"
                      secondary
                      icon="edit"
                      onPress={() => startMedication(item)}
                    />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Button
                      title="Eliminar"
                      secondary
                      icon="trash"
                      onPress={() => removeMedication(item)}
                    />
                  </View>
                </View>
              </Card>
            ))
          )}
        </>
      )}
    </Sheet>
  );
}

const local = StyleSheet.create({
  switchRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  actions: { flexDirection: 'row', gap: 9, marginTop: 6 },
});
